import {cancelRender, continueRender, delayRender, staticFile} from 'remotion';

const BN = 'U+0951-0952,U+0964-0965,U+0980-09FE,U+1CF7,U+200C-200D,U+20B9,U+25CC';
const LATIN = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+FEFF';
const faces: [string, string, string][] = [
  ['hind-siliguri-bengali-400-normal.woff2', '400', BN],
  ['hind-siliguri-bengali-600-normal.woff2', '600', BN],
  ['hind-siliguri-bengali-700-normal.woff2', '700', BN],
  ['hind-siliguri-latin-600-normal.woff2', '400 700', LATIN],
];
const withTimeout = <T,>(p: Promise<T>, ms: number) =>
  Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(new Error('font timeout')), ms))]);

const loadAll = () =>
  Promise.all(
    faces.map(async ([file, weight, range]) => {
      const f = new FontFace('Hind Siliguri', `url(${staticFile('fonts/' + file)}) format('woff2')`, {weight, unicodeRange: range});
      await f.load();
      (document.fonts as unknown as {add: (f: FontFace) => void}).add(f);
    }),
  );

const handle = delayRender('Loading Hind Siliguri', {timeoutInMilliseconds: 120000});
(async () => {
  for (let i = 0; i < 4; i++) {
    try { await withTimeout(loadAll(), 15000); continueRender(handle); return; } catch (e) { if (i === 3) throw e; }
  }
})().catch((e) => cancelRender(e));
