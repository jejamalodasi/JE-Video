import React, {createContext, useContext} from 'react';
import {AbsoluteFill, interpolate, Sequence, useCurrentFrame} from 'remotion';
import {FADE} from '../theme';

// Global frame (frame in the whole video) available inside any scene.
export const GFContext = createContext(0);
export const useGF = () => useContext(GFContext);

const Inner: React.FC<{a: number; start: number; first?: boolean; children: React.ReactNode}> = ({a, start, first, children}) => {
  const gf = useCurrentFrame() + a;
  const o = first ? 1 : interpolate(gf, [start - FADE, start + FADE], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <GFContext.Provider value={gf}>
      <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>
    </GFContext.Provider>
  );
};

// A scene is visible from start-FADE to end+FADE (cross-fade with neighbours).
export const SceneShell: React.FC<{start: number; end: number; first?: boolean; children: React.ReactNode}> = ({start, end, first, children}) => {
  const a = Math.max(0, start - FADE);
  return (
    <Sequence from={a} durationInFrames={end + FADE - a}>
      <Inner a={a} start={start} first={first}>{children}</Inner>
    </Sequence>
  );
};
