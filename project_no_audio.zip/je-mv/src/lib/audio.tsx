import React, {createContext, useContext, useEffect, useState} from 'react';
import {cancelRender, continueRender, delayRender, staticFile} from 'remotion';

export type AudioData = {
  fps: number; frames: number; bpm: number; beats: number[]; bands: number;
  spectrum: number[][]; bass: number[]; mid: number[]; treble: number[]; rms: number[];
};
const Ctx = createContext<AudioData | null>(null);

// Loads REAL per-frame analysis produced by scripts/analyze_audio.py
export const AudioDataProvider: React.FC<{children: React.ReactNode}> = ({children}) => {
  const [d, setD] = useState<AudioData | null>(null);
  const [h] = useState(() => delayRender('audio-data'));
  useEffect(() => {
    fetch(staticFile('data/audio-data.json')).then((r) => r.json()).then((j) => { setD(j); continueRender(h); }).catch((e) => cancelRender(e));
  }, [h]);
  if (!d) return null;
  return <Ctx.Provider value={d}>{children}</Ctx.Provider>;
};
export const useAudio = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error('AudioData missing');
  return c;
};

export const frameAudio = (d: AudioData, frame: number) => {
  const f = Math.max(0, Math.min(d.frames - 1, Math.floor(frame)));
  const p = Math.max(0, f - 1);
  const bands = d.spectrum[f].map((v, i) => (v * 0.65 + d.spectrum[p][i] * 0.35) / 255);
  let lo = 0, hi = d.beats.length - 1, idx = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (d.beats[m] <= f) { idx = m; lo = m + 1; } else hi = m - 1; }
  const since = idx >= 0 ? f - d.beats[idx] : 99;
  return {bands, bass: d.bass[f], mid: d.mid[f], treble: d.treble[f], rms: d.rms[f], pulse: Math.exp(-since / 7)};
};
export const useAudioFrame = (gf: number) => frameAudio(useAudio(), gf);

// Snap a time (sec) to a detected beat. mode: nearest | after | before.
export const snapToBeat = (d: AudioData, sec: number, mode: 'nearest' | 'after' | 'before', maxSec = 0.8) => {
  const target = sec * d.fps;
  let best = Math.round(target), bd = Infinity;
  for (const b of d.beats) {
    if (mode === 'after' && b < target) continue;
    if (mode === 'before' && b > target) continue;
    const dist = Math.abs(b - target);
    if (dist < bd) { bd = dist; best = b; }
  }
  return bd <= maxSec * d.fps ? best : Math.round(target);
};
