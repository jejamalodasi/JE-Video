import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, spring, staticFile, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {useGF} from '../lib/gf';
import {useAudioFrame} from '../lib/audio';
import {BlurredBackdrop, FilmGrain, LightLeak, NightHaze, Particles, Vignette} from '../components/Backdrop';
import {CircularSpectrum, EqualizerBars} from '../components/Visualizers';
import {Grade, KenBurns} from '../components/KenBurns';
import {Lyrics} from '../components/Lyrics';

const {colors: C, font} = theme;
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
type S = {start: number; end: number};

// ---------- Opening: logo + studio name, then cover art ----------
export const OpeningScene: React.FC<S> = ({start, end}) => {
  const gf = useGF();
  const {fps} = useVideoConfig();
  const a = useAudioFrame(gf);
  const logoIn = spring({frame: gf - 10, fps, config: {damping: 16, stiffness: 90}});
  const logoOut = interpolate(gf, [fps * 4.4, fps * 5.4], [1, 0], clamp);
  const txt = interpolate(gf, [fps * 1.2, fps * 2.0], [0, 1], clamp);
  const coverIn = interpolate(gf, [fps * 4.8, fps * 6.0], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  return (
    <AbsoluteFill>
      <NightHaze />
      <Particles />
      <CircularSpectrum cx={960} cy={440} radius={170} maxLen={110} gain={1.4} opacity={logoOut * 0.9} />
      <AbsoluteFill style={{opacity: logoOut, alignItems: 'center', justifyContent: 'center'}}>
        <div style={{position: 'absolute', top: 440 - 130, width: 260, height: 260, borderRadius: '50%', overflow: 'hidden', transform: `scale(${0.8 + 0.2 * logoIn + 0.03 * a.pulse})`, opacity: logoIn, boxShadow: `0 0 ${30 + 50 * a.bass}px rgba(215,20,26,0.55)`}}>
          <Img src={staticFile('images/logo.jpg')} style={{width: '100%', height: '100%'}} />
        </div>
        <div style={{position: 'absolute', top: 700, fontFamily: font, fontWeight: 600, fontSize: 64, color: '#fff', opacity: txt, transform: `translateY(${(1 - txt) * 20}px)`, textShadow: '0 3px 20px rgba(0,0,0,0.6)'}}>JE Music Studios</div>
        <div style={{position: 'absolute', top: 790, width: 120 * txt, height: 4, background: C.red, boxShadow: `0 0 14px ${C.red}`, borderRadius: 2}} />
      </AbsoluteFill>
      <AbsoluteFill style={{opacity: coverIn}}>
        <KenBurns src="images/cover.jpg" start={fps * 4.8} end={end} scale={[1.0, 1.1]} origin="62% 45%" />
        <Vignette strength={0.45} />
      </AbsoluteFill>
      <LightLeak at={Math.round(fps * 4.8)} />
      <FilmGrain opacity={0.08} />
    </AbsoluteFill>
  );
};

// ---------- S1: portrait, slow zoom, lyrics bottom-centre ----------
export const PortraitScene: React.FC<S & {ids: number[]; leak?: boolean}> = ({start, end, ids, leak}) => (
  <AbsoluteFill>
    <KenBurns src="images/artist.jpg" start={start} end={end} scale={[1.04, 1.2]} origin="50% 28%" posY={[24, 24]} filter="saturate(0.9) contrast(1.05)" />
    <Grade scrim="bottom" blue={0.28} />
    <Particles opacity={0.8} />
    <Vignette />
    {leak && <LightLeak at={start} />}
    <Lyrics ids={ids} layout={{align: 'center', x: 160, y: 96, anchor: 'bottom', maxWidth: 1600, fontSize: 86}} />
    <FilmGrain />
  </AbsoluteFill>
);

// ---------- S2: slow tilt up the portrait, lyrics lower-left ----------
export const TiltScene: React.FC<S & {ids: number[]}> = ({start, end, ids}) => (
  <AbsoluteFill>
    <KenBurns src="images/artist.jpg" start={start} end={end} scale={[1.2, 1.32]} origin="18% 20%" posY={[28, 14]} filter="saturate(0.9) contrast(1.05)" />
    <Grade scrim="left" blue={0.4} />
    <AbsoluteFill style={{background: 'linear-gradient(to top, rgba(3,10,42,0.7) 0%, transparent 40%)'}} />
    <Particles opacity={0.8} />
    <Vignette />
    <Lyrics ids={ids} layout={{align: 'left', x: 120, y: 110, anchor: 'bottom', maxWidth: 1050, fontSize: 82}} />
    <FilmGrain />
  </AbsoluteFill>
);

// ---------- S3: instrumental -> real audio spectrum around the artist ----------
export const SpectrumScene: React.FC<S> = ({start, end}) => {
  const gf = useGF();
  const a = useAudioFrame(gf);
  const t = gf - start;
  const nameIn = interpolate(t, [20, 50], [0, 1], clamp);
  const CY = 450;
  return (
    <AbsoluteFill>
      <BlurredBackdrop src="images/cover_blur.jpg" />
      <Particles />
      <EqualizerBars height={95} opacity={0.4} gain={1.1} />
      <CircularSpectrum cx={960} cy={CY} radius={238} maxLen={170} gain={1.25} />
      <div style={{position: 'absolute', left: 960 - 215, top: CY - 215, width: 430, height: 430, borderRadius: '50%', overflow: 'hidden', border: '5px solid #fff', transform: `scale(${1 + 0.03 * a.pulse * (0.4 + a.bass)})`, boxShadow: `0 0 ${40 + 60 * a.bass}px rgba(215,20,26,0.6)`}}>
        <Img src={staticFile('images/artist.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: '50% 22%', transform: 'translateY(20%) scale(1.9)', transformOrigin: '50% 25%'}} />
      </div>
      <div style={{position: 'absolute', top: 895, width: '100%', textAlign: 'center', fontFamily: font, fontWeight: 600, fontSize: 56, color: '#fff', opacity: nameIn, transform: `translateY(${(1 - nameIn) * 16}px)`, textShadow: '0 3px 18px rgba(0,0,0,0.7)'}}>JE Jamal Odasi</div>
      <div style={{position: 'absolute', top: 872, left: 960 - 60 * nameIn, width: 120 * nameIn, height: 4, background: C.red, boxShadow: `0 0 12px ${C.red}`}} />
      <div style={{position: 'absolute', left: 110, top: 895, fontFamily: font, color: '#e9eeff', opacity: nameIn, fontSize: 34, lineHeight: 1.3, textShadow: '0 2px 12px rgba(0,0,0,0.8)'}}>Lyrics<br /><b style={{fontWeight: 600, color: '#fff'}}>Nurl Alam</b></div>
      <div style={{position: 'absolute', right: 110, top: 895, textAlign: 'right', fontFamily: font, color: '#e9eeff', opacity: nameIn, fontSize: 34, lineHeight: 1.3, textShadow: '0 2px 12px rgba(0,0,0,0.8)'}}>Music<br /><b style={{fontWeight: 600, color: '#fff'}}>JE Jamal Odasi</b></div>
      <LightLeak at={start} />
      <Vignette />
      <FilmGrain />
    </AbsoluteFill>
  );
};

// ---------- S4: split layout, framed portrait left, lyrics right ----------
export const SplitScene: React.FC<S & {ids: number[]}> = ({start, end, ids}) => {
  const gf = useGF();
  const p = interpolate(gf, [start, end], [0, 1], clamp);
  const a = useAudioFrame(gf);
  const inP = spring({frame: Math.max(0, gf - start), fps: 30, config: {damping: 18, stiffness: 70}});
  return (
    <AbsoluteFill>
      <BlurredBackdrop src="images/cover_blur.jpg" drift={1.6} />
      <Particles />
      <div style={{position: 'absolute', left: 110, top: 100, width: 880, height: 880, overflow: 'hidden', transform: `translateX(${(1 - inP) * -60}px)`, opacity: inP, boxShadow: '0 30px 80px rgba(0,0,0,0.55)', borderLeft: `8px solid ${C.red}`}}>
        <Img src={staticFile('images/artist.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${1.04 + 0.12 * p + 0.004 * a.pulse}) translateY(${-p * 2}%)`, transformOrigin: '50% 35%'}} />
        <AbsoluteFill style={{background: C.blue, mixBlendMode: 'multiply', opacity: 0.25}} />
      </div>
      <Lyrics ids={ids} layout={{align: 'left', x: 1070, y: 380, anchor: 'top', maxWidth: 760, fontSize: 80}} />
      <LightLeak at={start} />
      <Vignette />
      <FilmGrain />
    </AbsoluteFill>
  );
};

// ---------- S5: cover art finale, slow zoom-out, spectrum bars ----------
export const CoverScene: React.FC<S & {ids: number[]}> = ({start, end, ids}) => (
  <AbsoluteFill>
    <KenBurns src="images/cover.jpg" start={start} end={end} scale={[1.14, 1.0]} origin="62% 50%" pulse={0.01} />
    <Grade scrim="bottom" blue={0.12} />
    <AbsoluteFill style={{background: 'linear-gradient(to top, rgba(3,10,42,0.55) 0%, transparent 45%)'}} />
    <Particles opacity={0.7} />
    <EqualizerBars height={110} opacity={0.55} gain={1.1} />
    <Vignette strength={0.5} />
    <LightLeak at={start} />
    <Lyrics ids={ids} layout={{align: 'center', x: 160, y: 150, anchor: 'bottom', maxWidth: 1600, fontSize: 84}} />
    <FilmGrain />
  </AbsoluteFill>
);

// ---------- Closing: logo ----------
export const ClosingScene: React.FC<S> = ({start}) => {
  const gf = useGF();
  const a = useAudioFrame(gf);
  const t = gf - start;
  const k = interpolate(t, [4, 24], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  return (
    <AbsoluteFill>
      <NightHaze />
      <Particles />
      <CircularSpectrum cx={960} cy={420} radius={170} maxLen={90} gain={1.2} opacity={0.7} />
      <div style={{position: 'absolute', left: 960 - 130, top: 420 - 130, width: 260, height: 260, borderRadius: '50%', overflow: 'hidden', opacity: k, transform: `scale(${0.9 + 0.1 * k + 0.02 * a.pulse})`}}>
        <Img src={staticFile('images/logo.jpg')} style={{width: '100%', height: '100%'}} />
      </div>
      <div style={{position: 'absolute', top: 725, width: '100%', textAlign: 'center', fontFamily: font, fontWeight: 600, fontSize: 60, color: '#fff', opacity: k, textShadow: '0 3px 18px rgba(0,0,0,0.6)'}}>JE Music Studios</div>
      <FilmGrain opacity={0.08} />
    </AbsoluteFill>
  );
};
