// Central theme. Colour scheme: "Royal Blue & Red" (cover-matched).
export const theme = {
  colors: {
    blue: '#0B1F6B',
    red: '#D7141A',
    white: '#FFFFFF',
    deep: '#07154A', // darker tint of blue for depth
    night: '#030A2A',
  },
  font: '"Hind Siliguri", sans-serif',
  fps: 30,
  durationInFrames: 5542, // 184.72s song @30fps (from audio analysis)
  ratio: '16:9' as '16:9' | '9:16' | '1:1' | '3:4',
};
export const RATIOS = {
  '16:9': {width: 1920, height: 1080},
  '9:16': {width: 1080, height: 1920},
  '1:1': {width: 1080, height: 1080},
  '3:4': {width: 1080, height: 1440},
} as const;
export const FADE = 9; // scene cross-fade half-length (frames)
