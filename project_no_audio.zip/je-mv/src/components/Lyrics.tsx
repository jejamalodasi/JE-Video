import React from 'react';
import {Easing, interpolate, useVideoConfig} from 'remotion';
import {CUES, LyricCue} from '../data/lyrics';
import {theme} from '../theme';
import {useGF} from '../lib/gf';
import {useAudioFrame} from '../lib/audio';

const CHORUS = /শাহ (জালাল|পরান)|দেখা দাও/;
export const isChorus = (c: LyricCue) => CHORUS.test(c.lines.join(' '));

// Words stay whole (no per-letter animation) so conjuncts / matras are intact.
export const layoutRows = (lines: string[]): string[][] =>
  lines.flatMap((line) => {
    const w = line.split(/\s+/).filter(Boolean);
    if (line.length <= 30 || w.length < 4) return [w];
    let best = 1, bd = Infinity;
    for (let i = 1; i < w.length; i++) {
      const l = w.slice(0, i).join(' ').length, r = w.slice(i).join(' ').length;
      if (Math.abs(l - r) < bd) { bd = Math.abs(l - r); best = i; }
    }
    return [w.slice(0, best), w.slice(best)];
  });

export type LyricLayout = {align: 'center' | 'left'; x: number; y: number; anchor: 'top' | 'bottom'; maxWidth: number; fontSize: number};

export const Lyrics: React.FC<{ids: number[]; layout: LyricLayout}> = ({ids, layout}) => {
  const gf = useGF();
  const {fps} = useVideoConfig();
  const a = useAudioFrame(gf);
  const t = gf / fps;
  const cue = CUES.find((c) => !c.music && ids.includes(c.id) && t >= c.start - 0.02 && t < c.end);
  if (!cue) return null;
  const rows = layoutRows(cue.lines);
  const chorus = isChorus(cue);
  const maxChars = Math.max(...rows.map((r) => r.join(' ').length));
  const fs = Math.min(layout.fontSize, layout.maxWidth / (maxChars * 0.5));
  const dur = cue.end - cue.start;
  const R = Math.min(dur * 0.55, 2.4);
  const flat = rows.flat();
  const weights = flat.map((w) => w.length + 1);
  const tot = weights.reduce((x, y) => x + y, 0);
  let acc = 0;
  const offsets = weights.map((w) => { const o = (acc / tot) * R; acc += w; return o; });
  const exit = interpolate(t, [cue.end - 0.4, cue.end - 0.05], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const glow = chorus ? '0 0 30px rgba(215,20,26,0.8), 0 3px 22px rgba(0,0,0,0.7)' : '0 0 24px rgba(11,31,107,0.95), 0 3px 18px rgba(0,0,0,0.75)';
  const pulse = 1 + (chorus ? 0.02 : 0.008) * a.pulse * (0.5 + a.bass);
  let k = 0;
  const underline = interpolate(t - cue.start, [0.25, 1.1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  return (
    <div style={{position: 'absolute', left: layout.x, width: layout.maxWidth, [layout.anchor]: layout.y, display: 'flex', flexDirection: 'column',
      alignItems: layout.align === 'center' ? 'center' : 'flex-start', opacity: exit, transform: `translateY(${(1 - exit) * -12}px) scale(${pulse})`,
      transformOrigin: layout.align === 'center' ? '50% 50%' : '0% 50%', fontFamily: theme.font, color: '#fff'} as React.CSSProperties}>
      {rows.map((row, ri) => (
        <div key={ri} style={{display: 'flex', flexWrap: 'nowrap', justifyContent: layout.align === 'center' ? 'center' : 'flex-start', fontSize: fs, lineHeight: 1.5, fontWeight: chorus ? 700 : 600, letterSpacing: 0}}>
          {row.map((w, wi) => {
            const o = offsets[k++];
            const p = interpolate(t - cue.start - o, [0, 0.45], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
            return <span key={wi} style={{display: 'inline-block', whiteSpace: 'pre', marginRight: wi < row.length - 1 ? '0.28em' : 0, opacity: p,
              transform: `translateY(${(1 - p) * 26}px) scale(${0.96 + 0.04 * p})`, filter: `blur(${(1 - p) * 9}px)`, textShadow: glow}}>{w}</span>;
          })}
        </div>
      ))}
      {chorus && <div style={{marginTop: 10, height: 4, borderRadius: 2, width: `${underline * 44}%`, background: theme.colors.red, boxShadow: `0 0 16px ${theme.colors.red}`, alignSelf: layout.align === 'center' ? 'center' : 'flex-start'}} />}
    </div>
  );
};
