import React from 'react';
import {AbsoluteFill, Img, random, staticFile, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {useGF} from '../lib/gf';
import {useAudioFrame} from '../lib/audio';

const {colors: C} = theme;

// Atmospheric night haze, bass-reactive red glow at the horizon.
export const NightHaze: React.FC = () => {
  const gf = useGF();
  const a = useAudioFrame(gf);
  const x = 50 + 12 * Math.sin(gf / 140), y = 38 + 8 * Math.cos(gf / 170);
  return (
    <AbsoluteFill style={{background: `radial-gradient(ellipse at ${x}% ${y}%, ${C.blue} 0%, ${C.deep} 48%, ${C.night} 100%)`}}>
      <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 115%, rgba(215,20,26,${0.16 + 0.32 * a.bass}) 0%, transparent 58%)`}} />
    </AbsoluteFill>
  );
};

const N = 64;
const P = Array.from({length: N}, (_, i) => ({
  x: random(`px${i}`), y: random(`py${i}`), s: 1.5 + random(`ps${i}`) * 4.5, v: 0.25 + random(`pv${i}`) * 0.75,
  ph: random(`pp${i}`) * 6.283, red: random(`pr${i}`) < 0.22,
}));
// Floating embers/dust. Motion constant; size/glow breathe with audio energy.
export const Particles: React.FC<{opacity?: number}> = ({opacity = 1}) => {
  const gf = useGF();
  const {width, height} = useVideoConfig();
  const a = useAudioFrame(gf);
  return (
    <AbsoluteFill style={{opacity, pointerEvents: 'none'}}>
      {P.map((p, i) => {
        const yy = (((p.y - gf * p.v * 0.0011) % 1) + 1) % 1;
        const xx = p.x + Math.sin(gf / 60 + p.ph) * 0.02;
        const tw = 0.45 + 0.55 * Math.sin(gf / 22 + p.ph);
        const size = p.s * (1 + 0.5 * a.pulse * a.bass);
        return (
          <div key={i} style={{
            position: 'absolute', left: xx * width, top: yy * height, width: size, height: size, borderRadius: '50%',
            background: p.red ? C.red : '#fff', opacity: Math.max(0.1, tw) * 0.75,
            boxShadow: `0 0 ${size * 3}px ${p.red ? C.red : '#cfd9ff'}`,
          }} />
        );
      })}
    </AbsoluteFill>
  );
};

export const FilmGrain: React.FC<{opacity?: number}> = ({opacity = 0.1}) => {
  const gf = useGF();
  const ox = Math.floor(random(`gx${gf}`) * 512), oy = Math.floor(random(`gy${gf}`) * 512);
  return <AbsoluteFill style={{backgroundImage: `url(${staticFile('images/grain.png')})`, backgroundPosition: `${ox}px ${oy}px`, mixBlendMode: 'overlay', opacity, pointerEvents: 'none'}} />;
};

export const Vignette: React.FC<{strength?: number}> = ({strength = 0.6}) => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at center, transparent 52%, rgba(3,10,42,${strength}) 100%)`, pointerEvents: 'none'}} />
);

// Soft light leak sweeping across at `at` (global frame).
export const LightLeak: React.FC<{at: number; len?: number}> = ({at, len = 42}) => {
  const gf = useGF();
  const t = (gf - at) / len;
  if (t < 0 || t > 1) return null;
  const o = Math.sin(Math.PI * t) * 0.55;
  return <AbsoluteFill style={{
    background: `radial-gradient(ellipse at ${-10 + t * 120}% 40%, rgba(255,120,110,0.85) 0%, rgba(215,20,26,0.35) 30%, transparent 62%)`,
    mixBlendMode: 'screen', opacity: o, pointerEvents: 'none'}} />;
};

// Background image, blurred + darkened + blue-graded (cinematic depth).
export const BlurredBackdrop: React.FC<{src: string; drift?: number}> = ({src, drift = 1}) => {
  const gf = useGF();
  return (
    <AbsoluteFill style={{overflow: 'hidden', background: C.night}}>
      <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: 'cover',
        transform: `scale(${1.25 + 0.03 * Math.sin(gf / 200)}) translate(${Math.sin(gf / 260) * 2 * drift}%, ${Math.cos(gf / 310) * 1.5 * drift}%)`}} />
      <AbsoluteFill style={{background: C.blue, mixBlendMode: 'multiply', opacity: 0.3}} />
    </AbsoluteFill>
  );
};
