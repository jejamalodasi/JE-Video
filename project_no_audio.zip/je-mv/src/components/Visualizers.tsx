import React from 'react';
import {useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {useGF} from '../lib/gf';
import {useAudioFrame} from '../lib/audio';

const {colors: C} = theme;

// Circular spectrum driven by the real 64-band FFT of the song (mirrored).
export const CircularSpectrum: React.FC<{cx: number; cy: number; radius: number; maxLen: number; gain?: number; opacity?: number}> = ({cx, cy, radius, maxLen, gain = 1, opacity = 1}) => {
  const gf = useGF();
  const {width, height} = useVideoConfig();
  const a = useAudioFrame(gf);
  const n = a.bands.length * 2;
  const rot = gf * 0.0015;
  return (
    <svg width={width} height={height} style={{position: 'absolute', left: 0, top: 0, opacity}}>
      <circle cx={cx} cy={cy} r={radius * (1 + 0.05 * a.bass * (0.4 + a.pulse))} fill="none" stroke={C.red} strokeWidth={3} opacity={0.5 + 0.4 * a.bass} />
      {Array.from({length: n}, (_, i) => {
        const b = i < n / 2 ? i : n - 1 - i;
        const v = Math.min(1, a.bands[b] * gain);
        const ang = (i / n) * Math.PI * 2 - Math.PI / 2 + rot;
        const r0 = radius + 8, r1 = r0 + 6 + v * maxLen;
        const hot = v > 0.72;
        return <line key={i} x1={cx + Math.cos(ang) * r0} y1={cy + Math.sin(ang) * r0} x2={cx + Math.cos(ang) * r1} y2={cy + Math.sin(ang) * r1}
          stroke={hot ? C.red : '#fff'} strokeWidth={7} strokeLinecap="round" opacity={0.5 + 0.5 * v} />;
      })}
    </svg>
  );
};

// Equalizer bars along the bottom (bass in the centre, mirrored).
export const EqualizerBars: React.FC<{height: number; opacity?: number; gain?: number}> = ({height, opacity = 1, gain = 1}) => {
  const gf = useGF();
  const {width} = useVideoConfig();
  const a = useAudioFrame(gf);
  const n = 64, gap = 6, bw = (width - gap * (n + 1)) / n;
  return (
    <div style={{position: 'absolute', left: 0, bottom: 0, width, height, display: 'flex', alignItems: 'flex-end', gap, paddingLeft: gap, opacity}}>
      {Array.from({length: n}, (_, i) => {
        const b = Math.min(a.bands.length - 1, Math.floor(Math.abs(i - (n - 1) / 2) * 2));
        const v = Math.min(1, a.bands[b] * gain);
        return <div key={i} style={{width: bw, height: Math.max(4, v * height), borderRadius: `${bw / 2}px ${bw / 2}px 0 0`,
          background: `linear-gradient(to top, ${C.blue}, #fff)`, boxShadow: v > 0.75 ? `0 0 14px ${C.red}` : undefined, borderTop: v > 0.75 ? `4px solid ${C.red}` : undefined}} />;
      })}
    </div>
  );
};
