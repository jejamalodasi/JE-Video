import React from 'react';
import {Audio, staticFile} from 'remotion';

// Original song audio = master timeline (untouched file).
export const PreviewAudio: React.FC = () => <Audio src={staticFile('audio/song.wav')} volume={1} />;
