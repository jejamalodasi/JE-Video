import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, staticFile} from 'remotion';
import {useGF} from '../lib/gf';
import {useAudioFrame} from '../lib/audio';

// Ken Burns zoom + slow pan/tilt (objectPosition) with a tiny beat-pulse. Never distorts the aspect ratio.
export const KenBurns: React.FC<{
  src: string; start: number; end: number; scale: [number, number]; origin?: string;
  posX?: [number, number]; posY?: [number, number]; filter?: string; pulse?: number;
}> = ({src, start, end, scale, origin = '50% 50%', posX = [50, 50], posY = [50, 50], filter, pulse = 0.006}) => {
  const gf = useGF();
  const a = useAudioFrame(gf);
  const p = interpolate(gf, [start, end], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.sin)});
  const s = (scale[0] + (scale[1] - scale[0]) * p) * (1 + pulse * a.pulse * (0.4 + a.bass));
  const x = posX[0] + (posX[1] - posX[0]) * p, y = posY[0] + (posY[1] - posY[0]) * p;
  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: `${x}% ${y}%`, transform: `scale(${s})`, transformOrigin: origin, filter}} />
    </AbsoluteFill>
  );
};

// Blue grade + bottom scrim so lyrics stay readable.
export const Grade: React.FC<{scrim?: 'bottom' | 'none' | 'left'; blue?: number}> = ({scrim = 'bottom', blue = 0.35}) => (
  <>
    <AbsoluteFill style={{background: '#0B1F6B', mixBlendMode: 'multiply', opacity: blue}} />
    {scrim === 'bottom' && <AbsoluteFill style={{background: 'linear-gradient(to top, rgba(3,10,42,0.92) 0%, rgba(3,10,42,0.55) 30%, rgba(3,10,42,0) 58%)'}} />}
    {scrim === 'left' && <AbsoluteFill style={{background: 'linear-gradient(to right, rgba(3,10,42,0.9) 0%, rgba(3,10,42,0.55) 40%, rgba(3,10,42,0) 70%)'}} />}
  </>
);
