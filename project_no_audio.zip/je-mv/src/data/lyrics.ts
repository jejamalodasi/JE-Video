// Auto-generated from public/data/lyrics.srt by scripts/build_lyrics.py
export type LyricCue = {id:number;start:number;end:number;lines:string[];music:boolean};
export const CUES: LyricCue[] = [
 {
  "id": 1,
  "start": 0.24,
  "end": 17.0,
  "lines": [
   "[music] JE Music Studios"
  ],
  "music": true
 },
 {
  "id": 2,
  "start": 17.0,
  "end": 19.04,
  "lines": [
   "শাহ জালাল বাবারে,"
  ],
  "music": false
 },
 {
  "id": 3,
  "start": 19.46,
  "end": 21.44,
  "lines": [
   "শাহ পরান বাবারে"
  ],
  "music": false
 },
 {
  "id": 4,
  "start": 22.5,
  "end": 26.26,
  "lines": [
   "একবার দেখা দাও",
   "আমারে।"
  ],
  "music": false
 },
 {
  "id": 5,
  "start": 26.38,
  "end": 28.721,
  "lines": [
   "শাহ জালাল বাবারে,"
  ],
  "music": false
 },
 {
  "id": 6,
  "start": 28.721,
  "end": 29.96,
  "lines": [
   "শাহ পরান বাবারে"
  ],
  "music": false
 },
 {
  "id": 7,
  "start": 30.88,
  "end": 35.08,
  "lines": [
   "একবার দেখা দাও",
   "আমারে"
  ],
  "music": false
 },
 {
  "id": 8,
  "start": 35.08,
  "end": 39.94,
  "lines": [
   "কাঙাল দুয়ারে খাড়া, কাঙাল",
   "দুয়ারে খাড়া"
  ],
  "music": false
 },
 {
  "id": 9,
  "start": 39.94,
  "end": 43.16,
  "lines": [
   "দেখিতে তোমারে শাহজালাল",
   "বাবারে।"
  ],
  "music": false
 },
 {
  "id": 10,
  "start": 44.12,
  "end": 49.04,
  "lines": [
   "একবার দেখা দাও আমারে",
   "শাহ জালাল বাবারে,"
  ],
  "music": false
 },
 {
  "id": 11,
  "start": 50.12,
  "end": 53.36,
  "lines": [
   "একবার দেখা দাও",
   "আমারে।"
  ],
  "music": false
 },
 {
  "id": 12,
  "start": 54.86,
  "end": 59.04,
  "lines": [
   "সুরমা নদী পাড়ি দিলা",
   "জায়নামাজ এ চরে"
  ],
  "music": false
 },
 {
  "id": 13,
  "start": 59.04,
  "end": 61.48,
  "lines": [
   "বাবা জায়নামাজ",
   "চরে।"
  ],
  "music": false
 },
 {
  "id": 14,
  "start": 64.459,
  "end": 67.78,
  "lines": [
   "সুরমা নদী পাড়ি দিলা",
   "জায়নামাজ এ চরে"
  ],
  "music": false
 },
 {
  "id": 15,
  "start": 67.78,
  "end": 71.36,
  "lines": [
   "বাবা জায়নামাজ",
   "চরে।"
  ],
  "music": false
 },
 {
  "id": 16,
  "start": 73.78,
  "end": 78.64,
  "lines": [
   "কাঙ্গালেরে ধরা দাও",
   "একবার আপন করে"
  ],
  "music": false
 },
 {
  "id": 17,
  "start": 78.64,
  "end": 83.3,
  "lines": [
   "একবার আপন করে। শাহ জালাল বাবারে,"
  ],
  "music": false
 },
 {
  "id": 18,
  "start": 83.3,
  "end": 88.76,
  "lines": [
   "শাহ পরান বাবারে একবার দেখা দাও আমারে"
  ],
  "music": false
 },
 {
  "id": 19,
  "start": 88.76,
  "end": 120.8,
  "lines": [
   "[Music] JE Jamal Odasi"
  ],
  "music": true
 },
 {
  "id": 20,
  "start": 120.84,
  "end": 123.86,
  "lines": [
   "রাইতে দিনে আসে মানুষ হাজারে হাজারে",
   "হাজারে হাজারে"
  ],
  "music": false
 },
 {
  "id": 21,
  "start": 123.86,
  "end": 127.48,
  "lines": [
   "বাবা তোমারই",
   "মাজারে"
  ],
  "music": false
 },
 {
  "id": 22,
  "start": 130.46,
  "end": 134.34,
  "lines": [
   "রাইতে দিনে আসে মানুষ হাজারে হাজারে"
  ],
  "music": false
 },
 {
  "id": 23,
  "start": 134.68,
  "end": 137.34,
  "lines": [
   "বাবা তোমারই মাজারে"
  ],
  "music": false
 },
 {
  "id": 24,
  "start": 139.76,
  "end": 143.96,
  "lines": [
   "মুই অভাগী দয়ার",
   "কাংগাল দয়া করো মোরে"
  ],
  "music": false
 },
 {
  "id": 25,
  "start": 143.96,
  "end": 148.74,
  "lines": [
   "বাবা দয়া করো মোরে",
   "শাহ জালাল বাবারে,"
  ],
  "music": false
 },
 {
  "id": 26,
  "start": 148.74,
  "end": 151.16,
  "lines": [
   "শাহ পরান বাবারে"
  ],
  "music": false
 },
 {
  "id": 27,
  "start": 152.08,
  "end": 154.44,
  "lines": [
   "একবার দেখা দাও আমারে"
  ],
  "music": false
 },
 {
  "id": 28,
  "start": 155.1,
  "end": 158.96,
  "lines": [
   "শাহ জালাল বাবারে, শাহ পরান বাবারে"
  ],
  "music": false
 },
 {
  "id": 29,
  "start": 159.06,
  "end": 164.72,
  "lines": [
   "একবার দেখা দাও আমারে"
  ],
  "music": false
 },
 {
  "id": 30,
  "start": 164.72,
  "end": 169.54,
  "lines": [
   "কাঙাল দুয়ারে খাড়া, কাঙাল",
   "দুয়ারে খাড়া দেখিতে তোমারে"
  ],
  "music": false
 },
 {
  "id": 31,
  "start": 169.54,
  "end": 174.86,
  "lines": [
   "শাহ জালাল বাবারে, একবার দেখা"
  ],
  "music": false
 },
 {
  "id": 32,
  "start": 174.86,
  "end": 178.46,
  "lines": [
   "দাও আমারে",
   "শাহ জালাল বাবারে,"
  ],
  "music": false
 },
 {
  "id": 33,
  "start": 179.72,
  "end": 182.36,
  "lines": [
   "একবার দেখা দাও আমারে"
  ],
  "music": false
 }
];
