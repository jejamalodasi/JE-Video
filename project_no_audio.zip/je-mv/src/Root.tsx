import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {RATIOS, theme} from './theme';

export const RemotionRoot: React.FC = () => {
  const {width, height} = RATIOS[theme.ratio];
  return <Composition id="Main" component={Main} durationInFrames={theme.durationInFrames} fps={theme.fps} width={width} height={height} />;
};
