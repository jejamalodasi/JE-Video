# HANDOFF — শাহজালাল বাবা (Music Video, Remotion)

1. **গান:** Shajalal Baba — JE Jamal Odasi (WAV, 184.72s, 44.1kHz স্টেরিও)। ধরন: ভক্তিমূলক/লোক ধাঁচ (শিরোনাম ও লিরিক্স থেকে), মাঝারি লয়, Bass-প্রধান সাউন্ড।
2. **নির্বাচিত Style:** Sufi Atmospheric (AI-নির্বাচিত মোড: Cinematic Photo Story + Kinetic Lyrics + Audio Spectrum)
3. **Color Scheme:** Royal Blue & Red — #0B1F6B, #D7141A, #FFFFFF (সহায়ক: #07154A, #030A2A)
4. **Aspect Ratio / FPS:** 16:9 (1920x1080), 30 FPS, মোট 5542 ফ্রেম (`src/theme.ts`)
5. **Scene Progress (সব তৈরি, Preview যাচাই সম্পন্ন):**
   - Opening (0:00–≈0:17): JE Music Studios লোগো + কভার
   - S1 (≈0:17–0:54): পোর্ট্রেট Ken Burns + লিরিক্স
   - S2 (≈0:54–1:28): Tilt/Pan + লিরিক্স (বাঁ দিকে)
   - S3 (≈1:28–2:00): ইন্সট্রুমেন্টাল, Circular Spectrum + Equalizer
   - S4 (≈2:00–2:28): Split layout
   - S5 (≈2:28–3:02): কভার ফিনালে + Equalizer
   - Closing (≈3:02–3:04): লোগো
   - Scene সীমানা SRT অংশ অনুযায়ী, সবচেয়ে কাছের শনাক্ত Beat-এ snap করা।
6. **Audio ও Lyrics সংক্রান্ত অনুমান:**
   - BPM ≈ 99–100 (অটো ডিটেকশন; অর্ধেক/দ্বিগুণ হওয়ার সামান্য সম্ভাবনা)।
   - Spectrum/Bass/Beat `public/data/audio-data.json` থেকে (`scripts/analyze_audio.py` দিয়ে প্রকৃত অডিও থেকে তৈরি)।
   - Lyrics Timing শুধু SRT থেকে (লাইন-লেভেল)। শব্দ-ভিত্তিক Reveal লাইনের ভেতরে অক্ষর-সংখ্যার অনুপাতে আনুমানিক, প্রকৃত Vocal ডিটেকশন নয়।
   - SRT শেষ 3:02.36, অডিও 3:04.72 — SRT অগ্রাধিকার, শেষ ≈2.4s Closing।
   - SRT-এর বানান অক্ষত; শুধু লাইনের শুরুর বাড়তি কমা বাদ।
   - Chorus চিহ্নিত হয় "শাহ জালাল/পরান" ও "দেখা দাও" লাইন দিয়ে।
   - লোগো মূল 225px; ≈260px-এ ব্যবহৃত, বড় করা যাবে না।
   - SFX `scripts/make_sfx.py` দিয়ে তৈরি (soft-whoosh, light-chime, soft-pop), ভলিউম ≈ 0.17–0.22।
7. **Commands:**
   - `npm install`
   - `npx remotion studio src/index.ts`
   - `npx remotion render src/index.ts Main out/video.mp4 --codec=h264`
   - Still: `npx remotion still src/index.ts Main out/still.png --frame=735`
   - অডিও ডেটা পুনরায় তৈরি: `python3 scripts/analyze_audio.py` (librosa লাগবে)
8. **পরবর্তী কাজ:** (ইউজার "রেন্ডার করো" বললে) চলন্ত Preview-তে Sync যাচাই → Final MP4 Render। অন্য Aspect Ratio চাইলে Layout পুনর্বিন্যাস দরকার (বর্তমানে শুধু 16:9 পরীক্ষিত)।

## আপডেট: Draft Render (540p) সম্পন্ন
- এই পরিবেশে (১ CPU) Full HD রেন্ডার অসম্ভব হওয়ায় Draft 960x540 MP4 তৈরি: `shajalal_baba_draft_540p.mp4` (H.264 + AAC, 184.7s, 30fps)।
- পদ্ধতি: ১৫০-ফ্রেমের অংশে রেন্ডার (`scripts/render_chunks.sh`), ffmpeg দিয়ে জোড়া, অডিও `scripts/mix_audio.py` দিয়ে (গান ×1.0 + SFX, Main.tsx-এর সময় অনুযায়ী) মিশিয়ে মাক্স।
- ভারী ইফেক্ট হালকা করা হয়েছে: রানটাইম ব্লারের বদলে `public/images/cover_blur.jpg`, স্পেকট্রাম রিংয়ের drop-shadow বাদ (≈২:৫০-এর পর)। প্রথম ≈২:৫০ পর্যন্ত রিংয়ে হালকা গ্লো আছে।
- Full HD: নিজের কম্পিউটারে `npm install` তারপর `npx remotion render src/index.ts Main out/video.mp4 --codec=h264`।
- যাচাই বাকি: চলন্ত ভিডিওতে পূর্ণ Sync চোখে দেখা (শুধু নির্বাচিত ফ্রেম ও অডিও লেভেল যাচাই হয়েছে)।
