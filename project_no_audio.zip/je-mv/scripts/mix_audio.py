"""Rebuild the final audio exactly as Main.tsx does (song @1.0 + SFX), via ffmpeg. Used when Remotion audio-only render is unavailable."""
import json, subprocess
d=json.load(open('public/data/audio-data.json')); beats=d['beats']; fps=30
def snap(sec,mode,mx=0.8):
    t=sec*fps; best=round(t); bd=1e9
    for b in beats:
        if mode=='after' and b<t: continue
        if mode=='before' and b>t: continue
        if abs(b-t)<bd: bd=abs(b-t); best=b
    return best if bd<=mx*fps else round(t)
b=dict(s1=snap(17.0,'before'),s2=snap(54.1,'nearest'),s3=snap(88.76,'after'),s4=snap(120.84,'before'),s5=snap(148.74,'after'),cl=snap(182.36,'after'))
ev=[('light-chime',9,.22),('soft-pop',40,.2),('soft-whoosh',round(30*4.6),.2)]
ev+=[('soft-whoosh',max(0,b[k]-16),.17) for k in ['s1','s2','s3','s4','s5']]
ev+=[('light-chime',max(0,b['cl']-6),.2)]
print(b)
cmd=['ffmpeg','-v','error','-y','-i','public/audio/song.wav']
for n,_,_ in ev: cmd+=['-i',f'public/sfx/{n}.wav']
fc=['[0:a]aformat=sample_rates=44100:channel_layouts=stereo[a0]']
for i,(n,f,v) in enumerate(ev,1):
    ms=int(f/fps*1000)
    fc.append(f'[{i}:a]aformat=sample_rates=44100:channel_layouts=stereo,volume={v},adelay={ms}|{ms}[s{i}]')
mix=''.join(['[a0]']+[f'[s{i}]' for i in range(1,len(ev)+1)])
fc.append(f'{mix}amix=inputs={len(ev)+1}:normalize=0:duration=first,alimiter=limit=0.95[out]')
cmd+=['-filter_complex',';'.join(fc),'-map','[out]','-t','184.733','out/audio.wav']
subprocess.run(cmd,check=True)
