#!/bin/bash
# Re-render FAILED ranges in small pieces (40 frames), named cNNa.. so they sort in order.
cd "$(dirname "$0")/.."
SCALE=${1:-0.5}
grep FAILED out/chunks.log | sed -E 's/FAILED chunk ([0-9]+) \(([0-9]+)-([0-9]+)\)/\1 \2 \3/' | sort -u | while read idx s e; do
  n=0
  for ((a=s; a<=e; a+=40)); do
    b=$((a+39)); [ $b -gt $e ] && b=$e
    f=out/chunks/c$(printf %02d $idx)$(printf "\\x$(printf %x $((97+n)))").mp4
    if [ ! -f "$f" ]; then
      for try in 1 2 3 4 5; do
        npx remotion render out/bundle Main "$f" --frames=$a-$b --muted --codec=h264 --scale=$SCALE --crf=26 --timeout=180000 --concurrency=1 \
          --browser-executable=/tmp/chromium --chrome-mode=headless-shell --gl=swangle >> out/repair.log 2>&1 && break
        rm -f "$f"
      done
    fi
    [ -f "$f" ] && echo "OK $f" >> out/repair.log || echo "FAILED $f ($a-$b)" >> out/repair.log
    n=$((n+1))
  done
done
echo REPAIRDONE >> out/repair.log
