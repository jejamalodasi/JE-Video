"""Real audio analysis -> public/data/audio-data.json (30fps)."""
import librosa, numpy as np, json
SR=22050; FPS=30; HOP=SR//FPS; NB=64
y,sr=librosa.load('public/audio/song.wav',sr=SR,mono=True)
dur=len(y)/sr
S=np.abs(librosa.stft(y,n_fft=2048,hop_length=HOP,center=True))
fr=librosa.fft_frequencies(sr=sr,n_fft=2048)
edges=np.geomspace(40,10000,NB+1)
bands=np.zeros((NB,S.shape[1]))
for i in range(NB):
    m=(fr>=edges[i])&(fr<edges[i+1])
    if not m.any(): m=np.argmin(abs(fr-edges[i]))
    bands[i]=S[m].mean(axis=0)
db=librosa.amplitude_to_db(bands,ref=np.max(bands))
lo,hi=np.percentile(db,5),np.percentile(db,99.5)
spec=np.clip((db-lo)/(hi-lo),0,1)
def grp(a,b):
    m=(fr>=a)&(fr<b); v=S[m].mean(axis=0); return v
def norm(v): return np.clip(v/np.percentile(v,99),0,1)
bass,mid,tre=norm(grp(20,250)),norm(grp(250,4000)),norm(grp(4000,11000))
rms=norm(librosa.feature.rms(S=S)[0])
tempo,beats=librosa.beat.beat_track(y=y,sr=sr,hop_length=HOP)
beat_frames=[int(b) for b in beats]
nf=int(np.ceil(dur*FPS))
def fit(a):
    a=np.asarray(a); 
    return a[:nf] if a.shape[-1]>=nf else np.pad(a,[(0,0)]*(a.ndim-1)+[(0,nf-a.shape[-1])])
out={'fps':FPS,'durationSec':round(dur,3),'frames':nf,'bpm':round(float(np.atleast_1d(tempo)[0]),1),
 'beats':beat_frames,'bands':NB,
 'spectrum':(fit(spec)*255).round().astype(int).T.tolist(),
 'bass':np.round(fit(bass),3).tolist(),'mid':np.round(fit(mid),3).tolist(),
 'treble':np.round(fit(tre),3).tolist(),'rms':np.round(fit(rms),3).tolist()}
json.dump(out,open('public/data/audio-data.json','w'),separators=(',',':'))
print('frames',nf,'beats',len(beat_frames),'bpm',out['bpm'])
