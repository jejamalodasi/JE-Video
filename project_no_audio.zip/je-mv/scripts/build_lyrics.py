"""SRT -> src/data/lyrics.ts (text kept as in SRT; only whitespace/stray leading comma cleaned)."""
import re, json, os
raw=open('public/data/lyrics.srt',encoding='utf-8').read().replace('\r','')
blocks=re.split(r'\n\s*\n(?=\d+\n\d\d:)',raw.strip())
def ts(s):
    h,m,r=s.split(':'); sec,ms=r.split(','); return int(h)*3600+int(m)*60+int(sec)+int(ms)/1000
out=[]
for b in blocks:
    ls=b.strip().split('\n')
    idx=int(ls[0]); a,bb=ls[1].split(' --> ')
    txt=[l.strip() for l in ls[2:] if l.strip()]
    music=any(t.lower().startswith('[music]') for t in txt)
    lines=[]
    for t in txt:
        t=re.sub(r'^[,،\s]+','',t)
        lines.append(t)
    # keep line breaks from SRT, but merge a trailing fragment pair when the 2nd row is a lone short word group
    out.append({'id':idx,'start':round(ts(a),3),'end':round(ts(bb),3),'lines':lines,'music':music})
os.makedirs('src/data',exist_ok=True)
js=json.dumps(out,ensure_ascii=False,indent=1)
open('src/data/lyrics.ts','w',encoding='utf-8').write(
"// Auto-generated from public/data/lyrics.srt by scripts/build_lyrics.py\nexport type LyricCue = {id:number;start:number;end:number;lines:string[];music:boolean};\nexport const CUES: LyricCue[] = "+js+";\n")
print(len(out),'cues')
