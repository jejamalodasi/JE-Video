#!/bin/bash
# Resumable chunked draft render (540p). Usage: bash scripts/render_chunks.sh [scale]
cd "$(dirname "$0")/.."
SCALE=${1:-0.5}; TOTAL=5542; STEP=${2:-150}; mkdir -p out/chunks
i=0
for ((s=0; s<TOTAL; s+=STEP)); do
  e=$((s+STEP-1)); [ $e -ge $((TOTAL-1)) ] && e=$((TOTAL-1))
  f=out/chunks/c$(printf %02d $i).mp4
  if [ ! -f "$f" ]; then
    for try in 1 2 3; do
      npx remotion render out/bundle Main "$f" --frames=$s-$e --muted --codec=h264 --scale=$SCALE --crf=26 --timeout=180000 --concurrency=1 \
        --browser-executable=/tmp/chromium --chrome-mode=headless-shell --gl=swangle >> out/chunks.log 2>&1 && break
      rm -f "$f"
    done
  fi
  [ -f "$f" ] && echo "OK chunk $i ($s-$e)" >> out/chunks.log || echo "FAILED chunk $i ($s-$e)" >> out/chunks.log
  i=$((i+1))
done
echo ALLDONE >> out/chunks.log
