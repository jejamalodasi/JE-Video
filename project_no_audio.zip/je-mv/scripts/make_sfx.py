"""Synthesise soft SFX (original, generated here). 44.1kHz mono 16-bit."""
import numpy as np, wave
SR=44100
def save(n,x):
    x=x/np.max(np.abs(x))*0.8
    w=wave.open(f'public/sfx/{n}.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((x*32767).astype('<i2').tobytes()); w.close()
rng=np.random.default_rng(7)
# soft whoosh: filtered noise swell
t=np.arange(int(1.1*SR))/SR
n=rng.standard_normal(len(t))
from scipy.signal import butter,lfilter
env=np.sin(np.pi*np.clip(t/1.1,0,1))**2
cut=300+2500*(t/1.1)
y=np.zeros_like(n)
for i in range(0,len(t),2048):
    b,a=butter(2,min(cut[i],9000)/(SR/2),'low'); y[i:i+2048]=lfilter(b,a,n[i:i+2048])
save('soft-whoosh',y*env)
# light chime
t=np.arange(int(2.2*SR))/SR
x=sum(a*np.sin(2*np.pi*f*t)*np.exp(-d*t) for f,a,d in [(880,1,2.2),(1320,.5,3),(1760,.3,4),(2217,.15,5)])
x*=np.minimum(1,t/0.005); save('light-chime',x)
# soft pop
t=np.arange(int(0.18*SR))/SR
x=np.sin(2*np.pi*(520-1800*t)*t)*np.exp(-t*28); save('soft-pop',x)
