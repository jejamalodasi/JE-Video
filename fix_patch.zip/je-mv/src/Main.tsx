import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {FontGate} from './lib/FontGate';
import {AudioDataProvider, snapToBeat, useAudio} from './lib/audio';
import {SceneShell} from './lib/gf';
import {PreviewAudio} from './components/PreviewAudio';
import {ClosingScene, CoverScene, OpeningScene, PortraitScene, SpectrumScene, SplitScene, TiltScene} from './scenes/Scenes';
import {theme} from './theme';

const SFX = (f: string) => staticFile(`sfx/${f}.wav`);

const Video: React.FC = () => {
  const d = useAudio();
  const total = theme.durationInFrames;
  // Scene boundaries come from SRT section times, snapped to REAL detected beats.
  const b = {
    s1: snapToBeat(d, 17.0, 'before'),
    s2: snapToBeat(d, 54.1, 'nearest'),
    s3: snapToBeat(d, 88.76, 'after'),
    s4: snapToBeat(d, 120.84, 'before'),
    s5: snapToBeat(d, 148.74, 'after'),
    cl: snapToBeat(d, 182.36, 'after'),
  };
  const whoosh = [b.s1, b.s2, b.s3, b.s4, b.s5];
  return (
    <AbsoluteFill style={{background: theme.colors.night}}>
      <SceneShell start={0} end={b.s1} first><OpeningScene start={0} end={b.s1} /></SceneShell>
      <SceneShell start={b.s1} end={b.s2}><PortraitScene start={b.s1} end={b.s2} ids={[2, 3, 4, 5, 6, 7, 8, 9, 10, 11]} /></SceneShell>
      <SceneShell start={b.s2} end={b.s3}><TiltScene start={b.s2} end={b.s3} ids={[12, 13, 14, 15, 16, 17, 18]} /></SceneShell>
      <SceneShell start={b.s3} end={b.s4}><SpectrumScene start={b.s3} end={b.s4} /></SceneShell>
      <SceneShell start={b.s4} end={b.s5}><SplitScene start={b.s4} end={b.s5} ids={[20, 21, 22, 23, 24, 25]} /></SceneShell>
      <SceneShell start={b.s5} end={b.cl}><CoverScene start={b.s5} end={b.cl} ids={[26, 27, 28, 29, 30, 31, 32, 33]} /></SceneShell>
      <SceneShell start={b.cl} end={total}><ClosingScene start={b.cl} end={total} /></SceneShell>

      <PreviewAudio />
      {/* Soft SFX, kept well under the song */}
      <Sequence from={9}><Audio src={SFX('light-chime')} volume={0.22} /></Sequence>
      <Sequence from={40}><Audio src={SFX('soft-pop')} volume={0.2} /></Sequence>
      <Sequence from={Math.round(30 * 4.6)}><Audio src={SFX('soft-whoosh')} volume={0.2} /></Sequence>
      {whoosh.map((f, i) => (
        <Sequence key={i} from={Math.max(0, f - 16)}><Audio src={SFX('soft-whoosh')} volume={0.17} /></Sequence>
      ))}
      <Sequence from={Math.max(0, b.cl - 6)}><Audio src={SFX('light-chime')} volume={0.2} /></Sequence>
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => (
  <FontGate>
    <AudioDataProvider>
      <Video />
    </AudioDataProvider>
  </FontGate>
);
