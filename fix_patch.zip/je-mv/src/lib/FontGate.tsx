import React, {useEffect, useState} from 'react';
import {cancelRender, continueRender, delayRender} from 'remotion';
import {FONT_DATA} from './fontData';

const BN = 'U+0951-0952,U+0964-0965,U+0980-09FE,U+1CF7,U+200C-200D,U+20B9,U+25CC';
const LATIN = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+FEFF';
const FACES = [
  {key: 'bn400', weight: '400', range: BN},
  {key: 'bn600', weight: '600', range: BN},
  {key: 'bn700', weight: '700', range: BN},
  {key: 'lat', weight: '400 700', range: LATIN},
];

// Loads Hind Siliguri from embedded data (no network). Children render only when fonts are ready.
export const FontGate: React.FC<{children: React.ReactNode}> = ({children}) => {
  const [handle] = useState(() => delayRender('fonts', {timeoutInMilliseconds: 60000}));
  const [ready, setReady] = useState(false);
  useEffect(() => {
    (async () => {
      for (const f of FACES) {
        const bin = atob(FONT_DATA[f.key]);
        const buf = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
        const face = new FontFace('Hind Siliguri', buf.buffer, {weight: f.weight, unicodeRange: f.range});
        await face.load();
        (document.fonts as unknown as {add: (x: FontFace) => void}).add(face);
      }
      setReady(true);
      continueRender(handle);
    })().catch((e) => cancelRender(e));
  }, [handle]);
  return ready ? <>{children}</> : null;
};
