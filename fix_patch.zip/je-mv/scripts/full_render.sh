#!/bin/bash
# Full HD (1080p) resumable render in 150-frame chunks -> out/shajalal_baba_1080p.mp4
# Run from project root:  bash scripts/full_render.sh      (safe to re-run; finished chunks are kept)
cd "$(dirname "$0")/.." || exit 1
TOTAL=5542; STEP=150; mkdir -p out/chunks
command -v ffmpeg >/dev/null || { sudo apt-get update -qq && sudo apt-get install -y -qq ffmpeg; }
rm -rf out/bundle; npx remotion bundle src/index.ts --out-dir=out/bundle || exit 1
i=0
for ((s=0; s<TOTAL; s+=STEP)); do
  e=$((s+STEP-1)); [ $e -ge $((TOTAL-1)) ] && e=$((TOTAL-1))
  f=out/chunks/c$(printf %02d $i).mp4
  if [ ! -f "$f" ]; then
    for try in 1 2 3 4; do
      npx remotion render out/bundle Main "$f" --frames=$s-$e --muted --codec=h264 --crf=20 --timeout=180000 ${BROWSER_ARGS:-} && break
      rm -f "$f"
    done
  fi
  [ -f "$f" ] || { echo "FAILED chunk $i ($s-$e). Run this script again."; exit 1; }
  echo "OK chunk $i ($s-$e)"; i=$((i+1))
done
ls "$PWD"/out/chunks/c*.mp4 | sort | sed "s#^#file '#;s#\$#'#" > out/list.txt
ffmpeg -v error -y -f concat -safe 0 -i out/list.txt -c copy out/video_silent.mp4 || exit 1
python3 scripts/mix_audio.py || exit 1
ffmpeg -v error -y -i out/video_silent.mp4 -i out/audio.wav -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart out/shajalal_baba_1080p.mp4 || exit 1
echo "DONE -> out/shajalal_baba_1080p.mp4"
